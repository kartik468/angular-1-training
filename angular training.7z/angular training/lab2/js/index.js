(function() {
	var myApp = angular.module('myApp', []);
	myApp.directive('simpleCalculator', function() {
        return {
            restrict: 'E',
            templateUrl: 'partials/calculator.html',
            controller: 'SimpleCalculatorController'
        };
    });

	myApp.controller('SimpleCalculatorController', ['$scope', function ($scope) {
		$scope.firstNumber = 0;
		$scope.secondNumber = 0;
		$scope.operator = "+";
		$scope.decimal = true;
	}]);
}());